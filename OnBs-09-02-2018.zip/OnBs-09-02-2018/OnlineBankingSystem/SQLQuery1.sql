create table AccountMaster
(
Account_No numeric(10) primary key,
Account_Type  varchar(50) not null check(Account_Type IN('Savings','Current')),
Balance float,
OpeningDate datetime,
Name varchar(50),
Email varchar(50),
Addrress varchar(100),
PancardNo varchar(10),
AccntAccessMode varchar(30) not null check(AccntAccessMode IN('Single','Joint','Either','Survivor')) 
)

create proc udp_insertAcnt
(
@acnt_no numeric(10),
@acnt_type varchar(50),
@balnc float,
@opndate datetime,
@name varchar(50),
@Email varchar(50),
@Addrress varchar(100),
@PancardNo varchar(10),
@AccntAccessMode varchar(30)
)
as
begin
insert into AccountMaster values(@acnt_no,@acnt_type,@balnc,@opndate,@name,@Email,@Addrress,@PancardNo,@AccntAccessMode)
end

exec udp_insertAcnt 125470000,'Savings',4500000,'01/19/1996', 'Aalekhya', 'Alekhya.poduri@gmail.com','Bangalore,','qw3456re','Single'

--Admin Login Credentials
create table AdminMaster
(
Username varchar(20),
Password varchar(10)
)

insert into AdminMaster values('pramesha','pram123')
insert into AdminMaster values('alekhya','alek123')
insert into AdminMaster values('rafi','rafi123')
insert into AdminMaster values('venkat','venk123')
insert into AdminMaster values('divyani','divy123')
insert into AdminMaster values('paavni','paav123')
insert into AdminMaster values('abdul','abdu123')
select * from AdminMaster