﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OBS.Entity;
using OBS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace OBS.DAL
{
    public class OBSDAL
    {
        public bool AddDetails(AccountMaster acntMast)
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OBSConnString"].ConnectionString);
                SqlCommand cmd = new SqlCommand("OBS.usp_insertAcnt", con);
                cmd.Parameters.Add(new SqlParameter("@acnt_type", Convert.ToString(acntMast.AccountType)));
                //cmd.Parameters.Add(new SqlParameter("@balnc", Convert.ToString(acntMast.Balance)));
                cmd.Parameters.Add(new SqlParameter("@opndate", Convert.ToString(acntMast.OpeningDate)));
                cmd.Parameters.Add(new SqlParameter("@name", Convert.ToString(acntMast.Name)));
                cmd.Parameters.Add(new SqlParameter("@Email", Convert.ToString(acntMast.Email)));
                cmd.Parameters.Add(new SqlParameter("@Addrress", Convert.ToString(acntMast.Address)));
                cmd.Parameters.Add(new SqlParameter("@PancardNo", Convert.ToString(acntMast.PancardNo)));
                cmd.Parameters.Add(new SqlParameter("@AccntAccessMode", Convert.ToString(acntMast.AccountAccessMode)));
                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
                if (cmd.ExecuteNonQuery() > 0)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        public int GetAccountNumber()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OBSConnString"].ConnectionString);
            
            string query = "Select max(account_no)+1 from AccountMaster";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int no = (int)cmd.ExecuteScalar();
            con.Close();
            return no;

        }

        public List<AccountMaster> ShowDetails()
        {
            try
            {
                List<AccountMaster> myList = new List<AccountMaster>();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OBSConnString"].ConnectionString);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    AccountMaster accntMast = new AccountMaster();
                    accntMast.AccountId = dr.GetInt32(0);
                    accntMast.AccountType = dr.GetString(1);
                    accntMast.Balance = (decimal)dr.GetDouble(2);
                    accntMast.OpeningDate = dr.GetDateTime(3);
                    accntMast.Name = dr.GetString(4);
                    accntMast.Email = dr.GetString(5);
                    accntMast.Address = dr.GetString(6);
                    accntMast.PancardNo = dr.GetString(7);

                }
                dr.Close();
                con.Close();

                return myList;
            }
            catch (Exception)
            {

                throw;
            }
        }

        public bool UpdateDetails(AccountMaster acntMast)
        {
            bool flag = false;
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OBSConnString"].ConnectionString);
                SqlCommand cmd = new SqlCommand("update udp_insertAcnt SEt =@acnt_type,=@balnc,=@opndate,@name,@Email,@Address,@PancardNo,@AccntAccessMode)", con);
                cmd.Parameters.AddWithValue("@acnt_type",acntMast.AccountType);
                cmd.Parameters.AddWithValue("@balnc", acntMast.Balance);
                cmd.Parameters.AddWithValue("@opndate", acntMast.OpeningDate);
                cmd.Parameters.AddWithValue("@name", acntMast.Name);
                cmd.Parameters.AddWithValue("@Email", acntMast.Email);
                cmd.Parameters.AddWithValue("@Address", acntMast.Address);
                cmd.Parameters.AddWithValue("@PancardNo", acntMast.PancardNo);
                cmd.Parameters.AddWithValue("@AccntAccessMode", acntMast.AccountAccessMode);

                con.Open();
                int ru = Convert.ToInt32(cmd.ExecuteNonQuery());
                con.Close();
                if (ru > 0)
                    flag = true;
            }
            catch (Exception)
            {

                throw;
            }
            return flag;
        }

        //public int MaxAccntId()
        //{
            
        //}
    }
}
