﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//using OBS.Entity;
//using OBS.Exceptions;
//using System.Data.SqlClient;
//using System.Configuration;

//namespace OBS.DAL
//{
//    public class AdminDAL
//    {
//        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
//        public bool AddData(AccountMaster a)
//        {
            
//        }

//        public bool UpdateData(AccountMaster a)
//        {
            
//        }

//        public AccountMaster SearchData(int id)
//        {
            
//        }

//        public bool DeleteData(int id)
//        {
            
//        }

//        public List<AccountMaster> ShowAllData()
//        {
//            try
//            {
//                List<AccountMaster> myList = new List<AccountMaster>();
//                SqlCommand cmd = new SqlCommand();
//                cmd.CommandType = System.Data.CommandType.StoredProcedure;
//                cmd.CommandText = "";
//                cmd.Connection = con;

//                con.Open();
//                SqlDataReader dr = cmd.ExecuteReader();

//                while (dr.Read())
//                {

//                }
//            }
//            catch (Exception)
//            {

//                throw;
//            }
//        }
//    }
//}
