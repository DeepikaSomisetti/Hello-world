﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OBS.Entity;
using OBS.Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace OBS.DAL
{
    public class LoginCredDAL
    {
        public bool LoginCredentials(Login rec)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["OBSConnString"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * OBS.LoginCreds where USERNAME=@u AND PASS=@p", con);

                cmd.Parameters.AddWithValue("@u", rec.Username);
                cmd.Parameters.AddWithValue("@p", rec.Password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
        }
    }
}
