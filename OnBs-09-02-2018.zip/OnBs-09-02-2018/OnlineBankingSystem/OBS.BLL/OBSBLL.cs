﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OBS.Entity;
using OBS.Exceptions;
using OBS.DAL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace OBS.BLL
{
    public class OBSBLL
    {
        OBSDAL obsDal = new OBSDAL();

        public bool Validations(AccountMaster acntMast)
        {
            StringBuilder sb = new StringBuilder();
            bool valid = true;
            if (acntMast.OpeningDate == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Opening Date cannot be null");
            }

            if (acntMast.Balance < 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Balance cannot be less than 0");
            }
            
            if (acntMast.OpeningDate > DateTime.Now)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Account opening date cannot be greater than current date");
            }

            if (acntMast.PancardNo == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Pancard number cannot be null");
            }

            if (acntMast.PancardNo.Length < 10 || acntMast.PancardNo.Length > 10)
            {
                valid = false;
                sb.Append(Environment.NewLine + "PanCard Number cannot be less than or greater than 10 digits");
            }

            var Exp = new Regex("[A-Za-z][0-9]+$");
            if (!(Exp.IsMatch(acntMast.PancardNo) == true))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Pan card number contains alphabets and numbers");
            }

            if (acntMast.Address.Length > 100)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Maximum length of the address is 100");
            }

            if (acntMast.Address == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Address cannot be empty");
            }

            if (acntMast.Email == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Email Id cannot be null");
            }

            if (valid == false)
                throw new OBSExceptions(sb.ToString());
            return valid;
        }

        public bool AddDetails(AccountMaster acntMast)
        {
            try
            {
                bool flag = false;
                //if (Validations(acntMast))
                //{
                //    flag = obsDal.AddDetails(acntMast);
                //}
                flag = obsDal.AddDetails(acntMast);
                return flag;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception p)
            {
                throw p;
            }
        }

        public List<AccountMaster> ShowDetails()
        {
            try
            {
                List<AccountMaster> myList = obsDal.ShowDetails();
                return myList;
            }
            catch (OBSExceptions ex)
            {

                throw ex;
            }
            catch (SqlException s)
            {
                throw s;
            }
            
            catch(Exception v)
            {
                throw v;
            }
        }

        public bool UpdateDetails(AccountMaster acntMast)
        {
            try
            {
                bool flag = false;
                if (Validations(acntMast))
                {
                    flag = obsDal.UpdateDetails(acntMast);
                }
                return flag;
            }
            catch (OBSExceptions obsEx)
            {
                throw obsEx;
            }
            catch (SqlException s)
            {
                throw s;
            }

            catch (Exception v)
            {
                throw v;
            }
        }

        //public int MaxAccntId()
        //{
        //    try
        //    {
        //        OBSDAL dobj = new OBSDAL();
        //        return dobj.MaxProdId();
        //    }
        //    catch (SqlException s)
        //    {
        //        throw s;
        //    }
        //    catch (Exception v)
        //    {
        //        throw v;
        //    }
        //}
    }
}
