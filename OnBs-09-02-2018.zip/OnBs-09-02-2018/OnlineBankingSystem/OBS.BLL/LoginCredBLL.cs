﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//using OBS.Entity;
//using OBS.Exceptions;
//using OBS.DAL;
//using System.Data.SqlClient;

//namespace OBS.BLL
//{
//    public class LoginCredBLL
//    {
//        public bool LoginCredentials(Login rec)
//        {
//            try
//            {
//                LoginCredDAL ldal = new LoginCredDAL();
//                bool flag = ldal.LoginCredentials(rec);

//                return flag;
//            }
//            catch (SqlException s)
//            {
//                throw s;
//            }
//            catch (Exception v)
//            {
//                throw v;
//            }
//        }

//    }
//}
