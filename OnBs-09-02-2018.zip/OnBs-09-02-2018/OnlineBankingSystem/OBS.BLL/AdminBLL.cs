﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//using OBS.Entity;
//using OBS.Exceptions;
//using OBS.DAL;

//namespace OBS.BLL
//{
//    public class AdminBLL
//    {
//        OBSDAL dal = new OBSDAL();
//        public bool AddData(AccountMaster a)
//        {
//            try
//            {
//                return dal.AddData(a);

//            }
//            catch (Exception v)
//            {

//                throw v;
//            }
//        }

//        public bool UpdateData(AccountMaster a)
//        {
//            try
//            {
//                return dal.UpdateData(a);
//            }
//            catch (Exception)
//            {

//                throw;
//            }
//        }

//        public AccountMaster SearchData(int id)
//        {
//            try
//            {
//                return dal.SearchData(id);
//            }
//            catch (Exception)
//            {

//                throw;
//            }
//        }

//        public bool DeleteData(int id)
//        {
//            try
//            {
//                return dal.DeleteData(id);
//            }
//            catch (Exception)
//            {

//                throw;
//            }
//        }

//        public List<AccountMaster> ShowAllData()
//        {
//            try
//            {
//                return dal.ShowAllData();
//            }
//            catch (Exception v)
//            {

//                throw v;
//            }
//        }
//    }
//}
