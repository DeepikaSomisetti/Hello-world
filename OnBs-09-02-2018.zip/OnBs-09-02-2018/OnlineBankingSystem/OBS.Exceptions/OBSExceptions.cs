﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OBS.Exceptions
{
    public class OBSExceptions:ApplicationException
    {
        public OBSExceptions()
        {

        }

        public OBSExceptions(string message):base(message)
        {

        }
    }
}
