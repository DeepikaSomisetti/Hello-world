﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OBS.Entity
{
    public class Transactions
    {
        public int TransactionID { get; set; }
        public DateTime DateofTransaction { get; set; }
        public string typeOfTransac { get; set; }
        public int AccountId { get; set; }
        public decimal Amount { get; set; }
    }
}
