﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OBS.Entity
{
    public class Facilities
    {
        public int FacilityId { get; set; }
        public string TypeOfFacility { get; set; }
        public int AccountID { get; set; }
        public string AccountType { get; set; }
    }
}
