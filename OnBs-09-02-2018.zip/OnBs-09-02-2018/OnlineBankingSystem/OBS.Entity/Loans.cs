﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OBS.Entity
{
    public class Loans
    {
        public int LoanID { get; set; }
        public int AccountID { get; set; }
        public string TypeOfLoan { get; set; }
        public int DurationOfLoan { get; set; }
        public int EMI { get; set; }
        public string ApplicationStatus { get; set; }
        public int LoanAmount { get; set; }
        public int Interest { get; set; }
    }
}
