﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using OBS.Entity;
using OBS.Exceptions;
using OBS.BLL;
using System.Data.SqlClient;

namespace OBS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AccountMaster accntMast = new AccountMaster();
                txtAccountNo.Text = accntMast.AccountId.ToString();
                accntMast.AccountType = cmbAccntType.Text;
                //accntMast.Balance = (float)Convert.ToDouble(txtBalance.Text);
                accntMast.OpeningDate = Convert.ToDateTime(datePicker.Text);
                accntMast.Name = txtxName.Text;
                accntMast.Email = txtEmail.Text;
                accntMast.Address = txtAddress.Text;
                accntMast.PancardNo = txtPancardNo.Text;
                
                if (rdCurrent.IsChecked == true)
                {
                    accntMast.AccountAccessMode = rdCurrent.Content.ToString();
                }
                else if (rdEither.IsChecked == true)
                {
                    accntMast.AccountAccessMode = rdEither.Content.ToString();
                }
                else if (rdSingle.IsChecked == true)
                {
                    accntMast.AccountAccessMode = rdSingle.Content.ToString();
                }
                else if (rdSurvivor.IsChecked == true)
                {
                    accntMast.AccountAccessMode = rdSurvivor.Content.ToString();
                }
                
                OBSBLL obsBll = new OBSBLL();
                bool flag = obsBll.AddDetails(accntMast);
            }
            catch (OBSExceptions obsEx)
            {
                MessageBox.Show(obsEx.Message.ToString());
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Message.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        
        }
    }
}
