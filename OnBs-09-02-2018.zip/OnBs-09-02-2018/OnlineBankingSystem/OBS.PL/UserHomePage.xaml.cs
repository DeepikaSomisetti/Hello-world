﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OBS.PL
{
    /// <summary>
    /// Interaction logic for UserHomePage.xaml
    /// </summary>
    public partial class UserHomePage : Window
    {
        public UserHomePage()
        {
            InitializeComponent();
        }

        private void btnemi_Click(object sender, RoutedEventArgs e)
        {
            int LoanAmount = 0;
            double EMI = 0;
            int InterestRate = 0;
            int PaymentPeriod=0;

            try
            {
                InterestRate = Convert.ToInt32(txtinterest.Text);
                PaymentPeriod = Convert.ToInt32(Convert.ToInt32(txtduration.Text)*12);
                LoanAmount = Convert.ToInt32(txtloanamount.Text);

                if(InterestRate>1)
                {
                    InterestRate = InterestRate / 100;
                }

                EMI = (LoanAmount * Math.Pow((InterestRate / 12) + 1, (PaymentPeriod)) * InterestRate / 12) / (Math.Pow(InterestRate / 12 + 1, (PaymentPeriod)) - 1);
                lblemi.Text = "EMI" + EMI.ToString("N2");
            }
            catch
            {

            }

        }
    }
}
