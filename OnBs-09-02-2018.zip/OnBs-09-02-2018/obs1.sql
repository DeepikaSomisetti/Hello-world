use Mumbai13Training;

-----Online Banking System schema
create schema OBS  

-------AccountMaster 
create table OBS.AccountMaster     
(
	Account_No int identity(1000000000,1) not null primary key,
	Account_Type  varchar(50),
	Balance Money,
	OpeningDate datetime,
	Name varchar(50),
	Email varchar(50),
	Addr varchar(100),
	PancardNo varchar(10),
	AccntAccessMode varchar(30) 
);

-----Transaction Table
create table OBS.Transactions
(
	Transaction_id  int identity(1,1) not null primary key,
	DateOfTransaction Datetime,
	TypeOfTransaction varchar(20),
	Account_No int foreign key references OBS.AccountMaster(Account_No),
	Amount Money
);

-------Facility table
Create table OBS.Facilities
(
	Facility_Id int identity(1,1) not null primary key,
	TypeofFacility varchar(24), 
	Account_No int references OBS.AccountMaster(Account_No),
	Account_Type  varchar(50) 
);

---------LOANS
create Table OBS.Loans
(
LoanID int identity(1,1) not null primary key,
Account_No int foreign key references OBS.AccountMaster(Account_No),
TypeOfLoan varchar(50),
DurationOfLoan int,
EMI float,
ApplicationStatus varchar(50) 
);

--------LOGINCREDS
create table OBS.LoginCreds
(
Username varchar(20) primary key,
Password varchar(20)
);

---------------------------------------------------------------------------
--  Stored Procedures
----------------------------------------------------------
--1. Insertion of Details 
create proc OBS.usp_insertAcnt
(
	@acnt_type varchar(50),
	@opndate datetime,
	@name varchar(50),
	@Email varchar(50),
	@Addrress varchar(100),
	@PancardNo varchar(10),
	@AccntAccessMode varchar(30)
)
as
begin
	insert into OBS.AccountMaster(Account_Type,Balance,OpeningDate,Name,Email,Addr,PancardNo,AccntAccessMode) values (@acnt_type,0,@opndate,@name,@Email,@Addrress,@PancardNo,@AccntAccessMode)
end
------------------------------------------------------------

--2. For Deposit & Withdraw

create proc OBS.usp_dwtrans
(
	@accno int,
	@dt datetime ,
	@typ varchar(20),
	@amt Money
)

as
SET XACT_ABORT ON

		If @amt < 0 
		Begin
			return 2 -- Amount is Negative
        End

		If @typ NOT IN ('Withdraw','Deposit')
		Begin
			return 0 
		End

		If Not Exists ( Select * from Mumbai13Training.OBS.AccountMaster where Account_No = @accno)
		Begin
			return 1 -- No Account Number
		End

		If @typ = 'Withdraw'
			Begin
		
				Begin Transaction
					Update Mumbai13Training.OBS.AccountMaster set Balance=Balance-@amt where Account_No=@accno and Balance >=@amt
					Insert into Mumbai13Training.OBS.Transactions(Account_No,DateOfTransaction,TypeOfTransaction,Amount) values (@accno,@dt,@typ,@amt)
		 
				if @@ROWCOUNT = 0
				Begin
				Rollback Transaction
					return 3 -- Insufficient Funds  
				End

		 Else
		 Begin
			Commit Transaction
			return 4 -- Success
		 End
	End

	if @typ = 'Deposit'
		Begin
			Begin Transaction
				Update Mumbai13Training.OBS.AccountMaster set Balance=Balance+@amt where Account_No=@accno
				Insert into Mumbai13Training.OBS.Transactions(Account_No,DateOfTransaction,TypeOfTransaction,Amount) values (@accno,@dt,@typ,@amt) 
			Commit Transaction 
			Return 4 -- Success
		 End

-------------------------------------------------------------------------
-- 3. Querying the Own AccountMaster Class based on Id

 create proc OBS.usp_ownacc
 (@accno int)
 as
 Begin
	select * from OBS.AccountMaster where Account_No=@accno
 End
 -------------------------------------------------------------------------
 -- 4. Funds Transfer

 create proc OBS.usp_fundstrans
 (
	@accno1 int,
	@accno2 int,
	@amt Money
)
as
SET XACT_ABORT ON

	DECLARE @COUNT1 INT, @COUNT2 INT
	If @amt < 0 
		Begin
			return 0 -- Amount is Negative
        End

	If Not Exists ( Select * from OBS.AccountMaster where Account_No = @accno1 or Account_No = @accno2 )
		Begin
			return 1 -- No Account Number
		End
	If Exists ( select * from OBS.AccountMaster where  Balance < @amt )
	Begin
		return 2 --No Sufficient Funds
	End
	Begin
	Begin Transaction
		update OBS.AccountMaster set Balance= Balance - @amt where Account_No =@accno1 and Balance >= @amt
		SET @COUNT1=@@ROWCOUNT
		update OBS.AccountMaster set Balance= Balance + @amt where Account_No= @accno2
		set @COUNT2=@@ROWCOUNT

		If @COUNT1=@COUNT2
		Begin
			Commit Transaction
			return 3 -- Success
		End
	
		ELSE
		Begin
			RollBack Transaction
			return 4 -- UnSuccessfull
		End	 
	End
---------------------------------------------------------------------------
-- 5.  Insert into LoginCreds Table

go
create proc OBS.usp_insertLogin
( @name varchar(20),
  @pass varchar(20)
)
as 
	Begin
		Insert into OBS.LoginCreds(Username,Password) values(@name,@pass)
	End
go
---------------------------------------------------------------------------
-- 6. Login Creds Verify
Go
create proc OBS.usp_login
( @name varchar(20),
  @pass varchar(20)
)
as
	Begin 
		Select * from OBS.LoginCreds where Username = @name and Password = @pass
	End
Go
 ---------------------------------------------------------------------------

-- Sample Data

--exec OBS.usp_insertAcnt 'Savings','20180208','Syed','syed@gmail.com','Mumbai','amacl908a0','Single'
--select * from OBS.AccountMaster
--select * from OBS.Transactions
--select * from obs.AccountMaster

