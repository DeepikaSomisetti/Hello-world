Add Functinality is done.

please use the sql file provided for tables.

09-02-2018
All UI layers are added.



