use Mumbai13Training

create schema TEMS

select * from TEMS.Employee

select * from TEMS.TravelDetails

select * from TEMS.Expense_Details

select * from TEMS.AdminLogin

select * from TEMS.Expense_Accepted

select * from TEMS.Expense_Rejected





------------------------------
 -----Employee Table
 -------------------------------
create table TEMS.Employee
(
Employee_Id int primary key,
Employee_FirstName varchar(30),
Employee_LastName varchar(20),
Location varchar(30),
Reimbursement_Account_No int unique not null,
Password varchar(30)
)
alter table TEMS.Employee alter column Reimbursement_Account_No varchar(30)

select * from TEMS.Employee

------------------------
---travel Details
-----------------
create table TEMS.TravelDetails
(
MR_Number int,
Employee_Id int references TEMS.Employee(Employee_Id),
Reason_For_Travel nvarchar(max),
FromCity varchar(30),
ToCity varchar(30),
Travel_Date datetime,
ReturnDate datetime,
Duration int
)

-------------------------------
------Expense details
-------------------------------

create table TEMS.Expense_Details
(
Expense_ReportId int primary key,
Expense_Type varchar(50),
Expense_Date datetime,
Amount_spent float,
Payment_Type nvarchar(50),
MR_Number int,
Reimbursement_Account_No int references TEMS.Employee(Reimbursement_Account_No),
Expense_status varchar(50)
)


------Admin Login-----
create table TEMS.AdminLogin(UserName  varchar(20),Password  varchar(20))


-----------------------
----Expense Accepted
---------------------

create table TEMS.Expense_Accepted(
Expense_ReportId int references TEMS.Expense_Details(Expense_ReportId),
Amount_paid float,
payment_Date datetime)
--------------------------
----Expense rejected
--------------------------

create table TEMS.Expense_Rejected(
Expense_ReportId int references TEMS.Expense_Details(Expense_ReportId),
Reason_for_rejection nvarchar(50),
Rejection_Date datetime
)

-----------------Procedures-------------------

-----Procedure for Registration
create proc TEMS.RegisterEmpProc
(
@eid as int,
@efname as varchar(30),
@elname as varchar(20),
@location as varchar(30),
@R_Ac_no as int,
@passwd as varchar(30),
@desig as varchar(30)
)
as
begin
insert into TEMS.Employee values('@eid','@efname','@elname','@location','@R_Ac_no','@passwd','@desig')
end

------Procedure for Travelling-------

create proc TEMS.TravelDetailproc
(@mrnum int,
@eid int,
@fcity varchar(30),
@tcity varchar(30),
@reason varchar(100),
@tdate datetime,
@rdate datetime,
@tdur int)
as 
begin
insert into TEMS.TravelDetails values(@mrnum,@eid,@fcity,@tcity,@reason,@tdate,@rdate,@tdur)
end


---------Procedure for Expense Details--------
create proc TEMS.ExpenseDetailproc
(@erid as int,
@etype as varchar(50),
@edate as datetime,
@amtspent as float,
@ptype as varchar(50),
@mrnum as int,
@R_Ac_no as varchar(30),
@expstatus as varchar(50),
@id as int
)
as 
begin
insert into TEMS.Expense_Details values(@erid,@etype,@edate,@amtspent,@ptype,@mrnum,@R_Ac_no,@expstatus,@id)
end


----update user details--------
create proc TEMS.UpdateUserProc(
@f as varchar(30),
@l as varchar(20),
@acc as int,
@p as varchar(30),
@i as int
)
as
begin
Update TEMS.Employee set Employee_FirstName=@f,Employee_LastName=@l,Reimbursement_Account_No=@acc,Password=@p where Employee_Id=@i
end 

----------Procedure for EmployeeLogin-------
create proc TEMS.logproc
(
@userid as varchar(30),
@password as varchar(30)
)
as
begin
select Employee_Id,Password from TEMS.Employee where Employee_Id=@userid and Password=@password
end


----------Show Expense Details Procedure-------------

create proc TEMS.Show_ExpenseDetailProc
(
@i as int
)
as
begin
select * from TEMS.Expense_Details where id=@i
end
drop proc TEMS.Show_ExpenseDetailProc
/* Check Account Number*/
Create proc TEMS.Check_AccNo
(
@i as int
)
as 
Begin
Select * from TEMS.Employee where Employee_Id=@i
End

/* Check MR_NO*/
create proc TEMS.Check_MR_NO
(
@i as int
)
as
Begin
Select * from TEMS.TravelDetails where Employee_Id=@i
End

/*Check Expense Date*/
create proc TEMS.Check_ExpenseDate
(
@mr as int
)
as
Begin
Select * from TEMS.TravelDetails where MR_Number=@mr
End

/*Check Analyst*/
create proc TEMS.Check_Analyst
(
@i as int
)
as
Begin
Select Designation from TEMS.Employee where Employee_Id=@i
End

/*Check Senior Analyst*/
create proc TEMS.Check_SrAnalyst
(
@i as int
)
as
Begin
Select Designation from TEMS.Employee where Employee_Id=@i
End


/* Check mgr*/
create proc TEMS.Check_Mgr
(
@i as int
)
as
Begin
Select Designation from TEMS.Employee where Employee_Id=@i
End


/* Check Seniormgr*/
create proc TEMS.Check_SrMgr
(
@i as int
)
as
Begin
Select Designation from TEMS.Employee where Employee_Id=@i
End


/*show travel details*/

create proc TEMS.Show_TravelProc
(
@i as int
)
as
begin
select * from TEMS.TravelDetails where Employee_Id=@i
end



/* Administrator details*/
create proc TEMS.AdminProc
(
@id as varchar(20),
@pass as varchar(20)
)
as
Begin
select * from TEMS.AdminLogin
where UserName=@id and Password=@pass
End

/*show expense Details*/
create proc TEMS.ExpenseProc
(
@id as int
)
as
Begin
select * from Expense_details
End

/* Search by mr_no*/
create proc TEMS.MRSearchProc
(
@mr as int
)
as
Begin
select * from Expense_details where MR_Number=@mr
End

/* Search by empid*/
create proc TEMS.EmpIDSearchProc
(
@id as int
)
as
Begin
select * from Expense_details where id=@id
End

/*check if travelled*/
create proc TEMS.CheckTravelProc
(
@id as int
)
as
Begin
select MR_Number from TravelDetails where Employee_Id=@id;
End


---stored procedures for accepting and projecting


create proc TEMS.Accept_RequestProc
(
@tid as int,
@payment as int,
@pdate as date
)
as
begin
insert into TEMS.Expense_Accepted values(@tid,@payment,@pdate)
end


create proc TEMS.Reject_RequestProc
(
@tid as int,
@reason as varchar(20),
@rejectdate as date
)
as 
begin
insert into TEMS.Expense_Reject values(@tid,@reason,@rejectdate)
end


create proc TEMS.ChkAmountAcceptProc
(
@id as int
)
as
begin
select Amount_spent from TEMS.Expense_Details where Expense_ReportId=@id
end

create proc TEMS.ChangeDbAcceptProc
(
@i as int,
@a as varchar(50)
)
as
begin
update TEMS.Expense_Details set Expense_status=@a where Expense_ReportId=@i
end

create proc TEMS.ChangeDbReject
(
@i as int,
@r as varchar(50)
)
as
begin
update TEMS.Expense_Details set Expense_status=@r where Expense_ReportId=@i
end


create proc TEMS.Check_RejectDateProc
(
@i as int
)
as
begin
select Expense_Date  from TEMS.Expense_Details where Expense_ReportId=@i
end


create proc TEMS.CheckIfAlreadyAccept
(
@i as int
)
as
begin
select Expense_ReportId from TEMS.Expense_Accepted where Expense_ReportId=@i
end

create proc TEMS.CheckIfAlreadyReject
(
@i as int
)
as
begin
select Expense_ReportId from TEMS.Expense_Reject where Expense_ReportId=@i
end


create proc TEMS.DeleteExpProc
(
@i as int
)
as
begin
delete from TEMS.Expense_Details where Expense_ReportId=@i
end


create proc TEMS.CheckExistsProc
(
@i as int
)
as
begin
select Expense_ReportId from TEMS.Expense_Details where Expense_ReportId=@i
end


create proc TEMS.NextEmpIdProc
as
begin
select nextID=max(Employee_Id)+1 from TEMS.Employee
end


create proc TEMS.NextEmpRepIdProc
as
begin
select nextID=max(Expense_ReportId)+1 from TEMS.Expense_Details
end



create proc TEMS.NextTravelId
as
begin
select nextID=max(MR_Number)+1 from TEMS.TravelDetails
end


