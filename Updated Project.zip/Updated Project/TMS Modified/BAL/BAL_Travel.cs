﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using DAL;
using System.Data;
using ExceptionTMS;
using System.Data.SqlClient;

namespace BAL
{
    public class BAL_Travel
    {
        public static bool validateRegisterEmp(Employee obj)
        {
            bool validate = true;
            StringBuilder sb = new StringBuilder();
            if(obj.FName==string.Empty || obj.LName==string.Empty ||obj.Password==string.Empty
                ||obj.Account_Number.ToString()==string.Empty || obj.Department==string.Empty|| obj.Designation==string.Empty)
            {
                validate = false;
                sb.Append("Fields can't be blank!");
            }
            int parsedValue;
            if (!int.TryParse(obj.ID.ToString(), out parsedValue))
            {
                validate = false;
                sb.Append("This is a number only field");
            }


            if (validate == false)
                throw new TMSExceptions(sb.ToString());

            return validate;

        }
        public static bool Register_New_Employee(Employee obj)
        {
            bool registerUser = false;
            try
            {
                if(validateRegisterEmp(obj))
                {
                    registerUser= DAL.DAL_Travel.Register_new_Employee(obj);
                }
            }
            catch(Exception ex)
            {
                throw new TMSExceptions(ex.Message);
            }
            return registerUser;
            
        }

        public static bool User_Login(int id, string password)
        {
            return DAL.DAL_Travel.UserLoginClick(id, password);
        }

        public static bool Update_User_Details(string fname,string lname,string accno,string pass,int id)
        {
            return DAL.DAL_Travel.Update_User_Details(fname, lname, accno, pass, id);
        }

        public static  bool validateTravelDetails(TravelDetails obj)
        {
            bool validate = true;
            StringBuilder sb = new StringBuilder();
           
            if(obj.Reason_for_Travel== string.Empty || obj.Journey_To==string.Empty || obj.Journey_From==string.Empty)
            {
                validate = false;
                sb.Append("Fields can't be Empty !");
            }

            if(obj.Travel_Date > obj.Return_Date)
            {
                validate = false;
                sb.Append("Travel Date can't be greater than Return Date !");
            }

            
            if (validate == false)
                throw new TMSExceptions(sb.ToString());

            return validate;
        }
        public static bool Create_Travel_Details(TravelDetails obj)
        {
            bool TrDetails = false;
            try
            {
                if (validateTravelDetails(obj))
                {
                    TrDetails = DAL.DAL_Travel.Create_Travel_Details(obj);
                }
            }
            catch (Exception ex)
            {
                throw new TMSExceptions(ex.Message);
            }
            return TrDetails;
            
        }

        public static bool ValidateExpenseDetails(ExpenseDetails obj)
        {
            bool validate = true;
            bool checkAccn = false;
            bool checkMrNo = false;
            bool checkExpDate = false;
            bool checkAnalyst = DAL.DAL_Travel.Check_Analyst(obj);
            bool checkSrAnalyst = DAL.DAL_Travel.Check_SrAnalyst(obj);
            bool checkMgr = DAL.DAL_Travel.Check_Mgr(obj);
            bool checkSrMgr = DAL.DAL_Travel.Check_SrMgr(obj);

            StringBuilder sb = new StringBuilder();

            if(obj.Account_Number==string.Empty || obj.Payment_Type==string.Empty || obj.Expense_Type==string.Empty)
            {
                validate = false;
                sb.Append("Account Number, Payment Type and Expense Type can't be empty !");
            }

            checkAccn = DAL.DAL_Travel.Check_AccNo(obj);
            if(!checkAccn)
            {
                validate = false;
                sb.Append("Account Number and Employee doesnt Match !");
            }

            checkMrNo=DAL.DAL_Travel.Check_MrNo(obj);
            if(!checkMrNo)
            {
                validate=false;
                sb.Append("No such Travel Exists for the Employee !");
            }

            checkExpDate = DAL.DAL_Travel.Check_ExpenseDate(obj);
            if(!checkExpDate)
            {
                validate = false;
                sb.Append("Expense Date must be in between Travelling Date and Return Date !");
            }

            if(checkAnalyst)
            {
                if(obj.Expense_Type=="Travel Fare" && obj.Amount>3000)
                {
                    validate = false;
                    sb.Append("Expense Request(Travel Fare) for Analyst can't exceed Rs.3000/-");
                }

                if(obj.Expense_Type=="Accomodation" && obj.Amount>5000)
                {
                    validate = false;
                    sb.Append("Expense Request(Accomodation) for Analyst can't exceed Rs.5000/- ");
                }

                if(obj.Expense_Type=="Food" && obj.Amount>2000)
                {
                    validate = false;
                    sb.Append("Expense Request(Food) for Analyst can't be more than Rs.2000/-");
                }
            }
            if (checkSrAnalyst)
            {
                if (obj.Expense_Type == "Travel Fare" && obj.Amount > 4000)
                {
                    validate = false;
                    sb.Append("Expense Request(Travel Fare) for Senior Analyst can't exceed Rs.4000/-");
                }

                if (obj.Expense_Type == "Accomodation" && obj.Amount > 6000)
                {
                    validate = false;
                    sb.Append("Expense Request(Accomodation) for Senior Analyst can't exceed Rs.6000/- ");
                }

                if (obj.Expense_Type == "Food" && obj.Amount > 3000)
                {
                    validate = false;
                    sb.Append("Expense Request(Food) for Senior Analyst can't be more than Rs.3000/-");
                }
            }

            if (checkMgr)
            {
                if (obj.Expense_Type == "Travel Fare" && obj.Amount > 5000)
                {
                    validate = false;
                    sb.Append("Expense Request(Travel Fare) for Manager can't exceed Rs.5000/-");
                }

                if (obj.Expense_Type == "Accomodation" && obj.Amount > 6000)
                {
                    validate = false;
                    sb.Append("Expense Request(Accomodation) for Manager can't exceed Rs.6000/- ");
                }

                if (obj.Expense_Type == "Food" && obj.Amount > 3000)
                {
                    validate = false;
                    sb.Append("Expense Request(Food) for Manager can't be more than Rs.3000/-");
                }
            }
            if (checkSrMgr)
            {
                if (obj.Expense_Type == "Travel Fare" && obj.Amount > 6000)
                {
                    validate = false;
                    sb.Append("Expense Request(Travel Fare) for Senior Manager can't exceed Rs.6000/-");
                }

                if (obj.Expense_Type == "Accomodation" && obj.Amount > 7000)
                {
                    validate = false;
                    sb.Append("Expense Request(Accomodation) for Senior Manager can't exceed Rs.7000/- ");
                }

                if (obj.Expense_Type == "Food" && obj.Amount > 4000)
                {
                    validate = false;
                    sb.Append("Expense Request(Food) for Senior Manager can't be more than Rs.4000/-");
                }
            }

            if (validate == false)
                throw new TMSExceptions(sb.ToString());

            return validate;
        }

        public static bool Create_Expense_Details(ExpenseDetails obj)
        {
            bool CrExDetails = false;
            try
            {
                if (ValidateExpenseDetails(obj))
                {
                    CrExDetails = DAL.DAL_Travel.CreateExpenseDetails(obj);
                }
            }
            catch (Exception ex)
            {
                throw new TMSExceptions(ex.Message);
            }
            return CrExDetails;
        }

        public static List<ExpenseDetails> ShowExpenseDetails(int id)
        {
           return DAL.DAL_Travel.ShowExpenseDetails(id);
        }

        public static List<TravelDetails> ShowtravelDetails(int id)
        {
            return DAL.DAL_Travel.ShowTravelDetails(id);
        }

        public static DataTable ShowAlltravelDetails()
        {
            return DAL.DAL_Travel.ShowAllTravelDetails();
        }

        public static bool Admin_Login(string id,string password)
        {
            return DAL.DAL_Travel.AdminLogin(id, password);
        }
        public static DataTable ShowAllExpenseDetails()
        {
            return DAL.DAL_Travel.ShowAllExpenseDetails();
        }

        public static DataTable SearchByMrNo(int MR_No)
        {
            return DAL.DAL_Travel.SearchByMrNo(MR_No);
        }

        public static DataTable SearchByEmpId(int EmpId)
        {
            return DAL.DAL_Travel.SearchByEmpID(EmpId);
        }

        public static bool ifTravlled(int EmpId)
        {
            return DAL.DAL_Travel.CheckIfTravelled(EmpId);
        }



        public static bool Validate_AcceptReq(Request_Accept obj)
        {
            bool validate = true;
            StringBuilder sb = new StringBuilder();
            bool chkAmount = false;

            if (!DAL.DAL_Travel.CheckExists(obj.Expense_ReportId))
            {
                validate = false;
                sb.Append("Report ID  Record doesn't Exist !");
            }

            if(DAL.DAL_Travel.CheckIfAlreadyAcc(obj.Expense_ReportId))
            {
                validate = false;
                sb.Append("You have already Accepted/Rejected this Request!");
            }

            chkAmount = DAL.DAL_Travel.ChkAmountForAccept(obj.Expense_ReportId, obj.Amount_Paid);
            if(!chkAmount)
            {
                validate=false;
                sb.Append("Reimbursed Amount can't be more than the Amount Spent !");
            }
            if (!DAL.DAL_Travel.Check_RejectDate(obj.Payment_Date, obj.Expense_ReportId))
            {
                validate = false;
                sb.Append("Payment Date can't be less than the Expense Date!");
            }

            if (validate == false)
                throw new TMSExceptions(sb.ToString());

            return validate;
            

        }
         public static bool Accept_Request(Request_Accept obj)
        {
            bool accReq = false;
            try
            {
                if (Validate_AcceptReq(obj))
                {
                    accReq =  DAL.DAL_Travel.Accept_Request(obj);;
                }
            }
            catch (Exception ex)
            {
                throw new TMSExceptions(ex.Message);
            }
            return accReq;
            
        }

         public static bool Validate_RejectReq(Reject_Request obj)
         {
             bool validate = true;
             StringBuilder sb = new StringBuilder();

             if(!DAL.DAL_Travel.CheckExists(obj.Expense_ReportId))
             {
                 validate = false;
                 sb.Append("Report ID  Record doesn't Exist !");
             }
             if (DAL.DAL_Travel.CheckIfAlreadyAcc(obj.Expense_ReportId))
             {
                 validate = false;
                 sb.Append("You have already Accepted/Rejected this Request!");
             }

             if(!DAL.DAL_Travel.Check_RejectDate(obj.Rejection_Date,obj.Expense_ReportId))
             {
                 validate=false;
                 sb.Append("Reject Date can't be less than the Expense Date!");
             }
             if (obj.Reason_For_Rejection == string.Empty)
             {
                 validate = false;
                 sb.Append("Reason for Rejection can't be empty!");
             }

             if (validate == false)
                 throw new TMSExceptions(sb.ToString());

             return validate;
         }
        public static bool Reject_Request(Reject_Request obj)
         {
             bool rejReq = false;
             try
             {
                 if (Validate_RejectReq(obj))
                 {
                     rejReq = DAL.DAL_Travel.Reject_Request(obj); 
                 }
             }
             catch (Exception ex)
             {
                 throw new TMSExceptions(ex.Message);
             }
             return rejReq;
         }

           public static bool ChangeDbAccept(int i)
        {
            return DAL.DAL_Travel.ChangeDbAccept(i);
        }

          public static bool ChangeDbReject(int i)
           {
               return DAL.DAL_Travel.ChangeDbReject(i);
           }

        public static bool DeleteExp(int id)
          {
              return DAL.DAL_Travel.DeleteExp(id);
          }

        public static int NextEmpId()
        {
            return DAL.DAL_Travel.NextEmpId();
        }

        public static int NextExpRepId()
        {
            return DAL.DAL_Travel.NextExpRepId();
        }

        public static int NextTravelId()
        {
            return DAL.DAL_Travel.NextTravelId();
        }
    }
}
