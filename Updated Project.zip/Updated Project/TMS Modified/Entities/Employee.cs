﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Employee
    {
        public int ID { get; set; }
        public string Account_Number { get; set; }
        public string  FName { get; set; }
        public string LName { get; set; }
        public string  Department { get; set; }
        public string Location { get; set; }
        public string Password { get; set; }
        public string Designation { get; set; }
    }
}
