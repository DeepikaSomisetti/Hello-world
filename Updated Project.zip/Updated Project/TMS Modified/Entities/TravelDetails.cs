﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class TravelDetails
    {
        public int MR_No { get; set; }
        public int ID { get; set; }
        public string Journey_From { get; set; }
        public string Journey_To { get; set; }
        public string Reason_for_Travel { get; set; }
        public DateTime Travel_Date { get; set; }
        public DateTime Return_Date { get; set; }
        public int Duration { get; set; }
        public DateTime Apply_Date { get; set; }
    }
}
