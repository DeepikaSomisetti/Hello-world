﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Request_Accept
    {/* Expense_ReportId int references TEMS.Expense_Details(Expense_ReportId),
 Amount_Paid int,
 Payment_Date date)*/
        public int Expense_ReportId { get; set; }
        public int Amount_Paid { get; set; }
        public DateTime Payment_Date  { get; set; }
    }
}
