﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class ExpenseDetails
    {
        public int Expense_Report_Id { get; set; }
        public string Expense_Type { get; set; }
        public DateTime Expense_Date { get; set; }
        public int Amount { get; set; }
        public string Payment_Type { get; set; }
        public int MR_No { get; set; }
        public string Account_Number { get; set; }
        public string Expense_Status { get; set; }
        public int ID { get; set; }
    }
}
