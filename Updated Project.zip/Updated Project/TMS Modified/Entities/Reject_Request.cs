﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities
{
    public class Reject_Request
    {
        public int Expense_ReportId { get; set; }
        public string Reason_For_Rejection { get; set; }
        public DateTime Rejection_Date { get; set; }
    }
}
