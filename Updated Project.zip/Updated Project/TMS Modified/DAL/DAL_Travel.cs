﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entities;
using System.Data.SqlClient;
using System.Data;
using ExceptionTMS;
using System.Configuration;
namespace DAL
{
    public class DAL_Travel
    {
       //public SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
        public static bool Register_new_Employee(Employee obj)
        {
            bool flag = false;
              SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q = "insert into Employee values(@id,@fname,@lname,@loc,@acc,@pass,@desig)";
            //SqlConnection con = new SqlConnection(cs);
            try
            {
              //  con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "TEMS.RegisterEmpProc";

                cmd.Connection = con;
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@eid", obj.ID));
                cmd.Parameters.Add(new SqlParameter("@efname", obj.FName));
                cmd.Parameters.Add(new SqlParameter("@elname", obj.LName));
                cmd.Parameters.Add(new SqlParameter("@location", obj.Location));
                cmd.Parameters.Add(new SqlParameter("@R_Ac_no", obj.Account_Number));
                cmd.Parameters.Add(new SqlParameter("@passwd", obj.Password));
                cmd.Parameters.Add(new SqlParameter("@desig", obj.Designation));
                if (cmd.ExecuteNonQuery() > 0)
                    flag = true;

                return flag;
            }
            catch (SqlException)
            {
                return flag;
            }
            finally
            {
                con.Close();

            }
        }

        public static bool UserLoginClick(int id, string password)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q = "select * from Employee";
            //SqlConnection con = new SqlConnection(cs);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.logproc";
            cmd.Parameters.Add(new SqlParameter("@userid", id));
            cmd.Parameters.Add(new SqlParameter("@password", password));
            cmd.Connection = con;

            con.Open();
            try
            {
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        string user = dr[0].ToString();
                        string pass = dr[1].ToString();
                        if (user == id.ToString() && pass == password)
                        {
                            flag = true;
                        }
                    }
                }
                    return flag;

            }
            catch (SqlException)
            {
                return flag;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Update_User_Details(string fname, string Lname, string AccNo, string Pass, int id)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q = "update Employee set First_Name=@f,Last_Name=@l,Account_Number=@acc,Pass=@p where id=@i";
            //SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.UpdateUserProc";
            cmd.Connection = con;
            try
            {
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@f", fname));
                cmd.Parameters.Add(new SqlParameter("@l", Lname));
                cmd.Parameters.Add(new SqlParameter("@acc", AccNo));
                cmd.Parameters.Add(new SqlParameter("@p", Pass));
                cmd.Parameters.Add(new SqlParameter("@i", id));
                if (cmd.ExecuteNonQuery() > 0)
                {
                    flag = true;
                }
                return flag;
            }
            catch (SqlException)
            {
                return flag;
            }
            finally
            {
                con.Close();
            }

        }


        public static bool Create_Travel_Details(TravelDetails obj)
        {
            bool flag = false;
            //string cs=@"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            string q = "insert into TEMS.TravelDetails values (@mrnum,@eid,@fcity,@tcity,@reason,@tdate,@rdate,@tdur)";
            //SqlConnection con = new SqlConnection(cs);

            //try
            //{
            //  con.Open();
            SqlCommand cmd = new SqlCommand();

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.TravelDetailProc";
            cmd.Connection = con;
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@mrnum", obj.MR_No));
            cmd.Parameters.Add(new SqlParameter("@eid", obj.ID));
            cmd.Parameters.Add(new SqlParameter("@fcity", obj.Journey_From));
            cmd.Parameters.Add(new SqlParameter("@tcity", obj.Journey_To));
            cmd.Parameters.Add(new SqlParameter("@reason", obj.Reason_for_Travel));
            cmd.Parameters.Add(new SqlParameter("@tdate", obj.Travel_Date));
            cmd.Parameters.Add(new SqlParameter("@rdate", obj.Return_Date));
            //cmd.Parameters.Add(new SqlParameter("@applydate", obj.Apply_Date));
            cmd.Parameters.Add(new SqlParameter("@tdur", obj.Duration));
            if (cmd.ExecuteNonQuery() > 0)
            {
                flag = true;
            }
            return flag;
            //}
            //catch (SqlException)
            //{
            //    return flag;
            //}
            //finally
            //{
            //    con.Close();
            //}
        }


        public static bool CreateExpenseDetails(ExpenseDetails obj)
        {
            bool result = false;
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= travelMngmt; Integrated Security=true";
            //string q = "insert into TEMS.Expense_Details values (@erid,@etype,@edate,@amtspent,@ptype,@mrnum,@R_Ac_no,@expstatus,@id)";
            //SqlConnection con = new SqlConnection(cs);
            try
            {

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "TEMS.ExpenseDetailproc";
                cmd.Connection = con;
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@erid", Convert.ToInt32(obj.Expense_Report_Id)));
                cmd.Parameters.Add(new SqlParameter("@etype", obj.Expense_Type));
                cmd.Parameters.Add(new SqlParameter("@edate", obj.Expense_Date));
                cmd.Parameters.Add(new SqlParameter("@amtspent", obj.Amount));
                cmd.Parameters.Add(new SqlParameter("@ptype", obj.Payment_Type));
                cmd.Parameters.Add(new SqlParameter("@mrnum", obj.MR_No));
                cmd.Parameters.Add(new SqlParameter("@R_Ac_no", obj.Account_Number));
                cmd.Parameters.Add(new SqlParameter("@expstatus", obj.Expense_Status));
                cmd.Parameters.Add(new SqlParameter("@id", obj.ID));

                if (cmd.ExecuteNonQuery() > 0)
                {
                    result = true;
                }

                return result;
            }


            catch (SqlException)
            {
                return result;
            }
            finally
            {
                con.Close();

            }
        }

        public static List<ExpenseDetails> ShowExpenseDetails(int id)
        {
            List<ExpenseDetails> l = new List<ExpenseDetails>();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q = "select * from TEMS.expense_details where ID=@i";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q, con);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Show_ExpenseDetailProc";
            cmd.Connection = con;
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@i", id));
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    ExpenseDetails obj = new ExpenseDetails();
                    obj.Expense_Report_Id = Convert.ToInt32(dr[0]);
                    obj.Expense_Type = Convert.ToString(dr[1]);
                    obj.Expense_Date = Convert.ToDateTime(dr[2]);
                    obj.Amount = Convert.ToInt32(dr[3]);
                    obj.Payment_Type = Convert.ToString(dr[4]);
                    obj.MR_No = Convert.ToInt32(dr[5]);
                    obj.Account_Number = Convert.ToString(dr[6]);
                    obj.Expense_Status = Convert.ToString(dr[7]);
                    obj.ID = Convert.ToInt32(dr[8]);
                    l.Add(obj);
                }
            }
            return l;
            //    SqlDataAdapter sda = new SqlDataAdapter(cmd);
            //    DataTable dt = new DataTable("Employee");
            //    try
            //    {

            //        sda.Fill(dt);
            //        return dt;

            //    }
            //    catch (SqlException se)
            //    {
            //        return dt;
            //        throw se;
            //    }
        }


        public static List<TravelDetails> ShowTravelDetails(int id)
        {

            List<TravelDetails> l = new List<TravelDetails>();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);


            //string q = "select * from Travel_details where ID=@i";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q, con);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Show_TravelProc";
            cmd.Connection = con;

            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q = "select * from TEMS.TravelDetails where Employee_Id=@i";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@i", id));
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    TravelDetails obj = new TravelDetails();
                    obj.MR_No = Convert.ToInt32(dr[0]);
                    obj.ID = Convert.ToInt32(dr[1]);
                    obj.Reason_for_Travel = Convert.ToString(dr[2]);
                    obj.Journey_From = Convert.ToString(dr[3]);
                    obj.Journey_To = Convert.ToString(dr[4]);
                    obj.Travel_Date = Convert.ToDateTime(dr[5]);
                    obj.Return_Date = Convert.ToDateTime(dr[6]);
                    obj.Duration = Convert.ToInt32(dr[7]);

                    l.Add(obj);
                }
            }
            return l;
            //cmd.Parameters.Add(new SqlParameter("@id", id));
            //SqlDataAdapter sda = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable("Employee");
            //try
            //{

            //    sda.Fill(dt);
            //    return dt;

            //}
            //catch (SqlException se)
            //{
            //    return dt;
            //    throw se;
            //}
            //finally
            //    {
            //        con.Close();
            //    }
        }

        public static bool Check_AccNo(ExpenseDetails obj)
        {
            bool checkAccn = true;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_AccNo";
            cmd.Connection = con;
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            //con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
                
            try
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (obj.Account_Number != dr[4].ToString())
                        {
                            checkAccn = false;
                        }
                    }
                }
                //con.Close();
                return checkAccn;
            }
            catch( TMSExceptions)
            {
                throw;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_MrNo(ExpenseDetails obj)
        {
            bool checkMrNo = false;
            
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q1 = "select * from Travel_Details where id=@i";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q1, con);
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_MR_NO";
            cmd.Connection = con;
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            //con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            try
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (obj.MR_No == Convert.ToInt32(dr[0]))
                        {
                            checkMrNo = true;
                            break;
                        }
                    }
                }
                //con.Close();
                return checkMrNo;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_ExpenseDate(ExpenseDetails obj)
        {
            bool checkExpDate = true;
            DateTime to;
            DateTime ret;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_ExpenseDate";
            cmd.Connection = con;
            //con.Open(); 
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q1 = "select * from Travel_Details where Mr_No=@mr";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q1, con);
            cmd.Parameters.Add(new SqlParameter("@mr", obj.MR_No));
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            try
            {
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        to = Convert.ToDateTime(dr[5]);
                        ret = Convert.ToDateTime(dr[6]);
                        if (obj.Expense_Date>ret || obj.Expense_Date<to)
                        {
                            checkExpDate = false;
                        }
                    }
                }
                //con.Close();
                return checkExpDate;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_Analyst(ExpenseDetails obj)
        {
            bool checkAnalyst = true;
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q1 = "select Designation from Employee where id=@i";


            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q1, con);
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_Analyst";
            cmd.Connection = con;
            con.Open(); 
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
           // con.Open();
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if(d!="Analyst")
                {
                    checkAnalyst = false;
                }
                    
                    //con.Close();
                return checkAnalyst;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool Check_SrAnalyst(ExpenseDetails obj)
        {
            bool checkSrAnalyst = true;
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q1 = "select Designation from Employee where id=@i";

            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q1, con);
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_SrAnalyst";
            cmd.Connection = con;
            con.Open(); 
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
           // con.Open();
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if (d != "Senior Analyst")
                {
                    checkSrAnalyst = false;
                }

                //con.Close();
                return checkSrAnalyst;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

 
        public static bool Check_Mgr(ExpenseDetails obj)
        {
            bool checkMgr = true;
          SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_Mgr";
            cmd.Connection = con;
            con.Open(); 
            
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
          
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if (d != "Manager")
                {
                    checkMgr = false;
                }

                //con.Close();
                return checkMgr;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }


        public static bool Check_SrMgr(ExpenseDetails obj)
        {
            bool checkSrMgr = true;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_SrMgr";
            cmd.Parameters.Add(new SqlParameter("@i", obj.ID));
            cmd.Connection = con;
            con.Open(); 
            string d = Convert.ToString(cmd.ExecuteScalar());
            try
            {
                if (d != "Senior Manager")
                {
                    checkSrMgr = false;
                }

                //con.Close();
                return checkSrMgr;
            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static DataTable ShowAllTravelDetails()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from TEMS.TravelDetails";
            cmd.Connection = con;
            con.Open(); 
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
        }
        public static bool AdminLogin(string id,string password)
        {
            bool login = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            string user;
            string pass;
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.AdminProce";
            cmd.Parameters.Add(new SqlParameter("@id", id));
            cmd.Parameters.Add(new SqlParameter("@pass", password));
            cmd.Connection = con;
            con.Open();
            try
            {
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                         user = dr[0].ToString();
                         pass = dr[1].ToString();
                        if (user == id && pass == password)
                            login = true;
                        break;
                    }
                }
                return login;
            }
            catch(TMSExceptions)
            {
                throw;
            }
            catch (SqlException sx)
            {
                throw sx;
            }
            finally
            {
                con.Close();
            }
        }

        public static DataTable ShowAllExpenseDetails()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from TEMS.Expense_Details";
            cmd.Connection = con;
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
            finally
            {
                con.Close();
            }
        }

        public static DataTable SearchByMrNo(int Mr_No)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.MRSearchProc";
            cmd.Connection = con;
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@mr", Mr_No));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
            finally
            {
                con.Close();
            }
        }
        public static DataTable SearchByEmpID(int EmpId)
        {
             SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.EmpIDSearchProc";
            cmd.Connection = con;
            con.Open();
            cmd.Parameters.Add(new SqlParameter("@id", EmpId));
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable("Employee");
            try
            {

                sda.Fill(dt);
                return dt;

            }
            catch (SqlException se)
            {
                return dt;
                throw se;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool CheckIfTravelled(int EmpId)
        {
            bool travelled = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.CheckTravelProc";
            cmd.Connection = con;
            
            cmd.Parameters.Add(new SqlParameter("@id", EmpId));
            con.Open();
            try
            {
                int r = Convert.ToInt32(cmd.ExecuteScalar());
                if (r > 0)
                    travelled = true;

            }
            catch (TMSExceptions)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                con.Close();
            }
            
            return travelled;
        }

        public static bool Accept_Request(Request_Accept obj)
        {
            bool result = false;
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            //string q = "insert into  TEMS.Expense_Accepted values (@tid,@payment,@pdate)";
            //SqlConnection con = new SqlConnection();
            try
            {

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "TEMS.Accept_RequestProc";
                cmd.Connection = con;
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@tid", Convert.ToInt32(obj.Expense_ReportId)));
                cmd.Parameters.Add(new SqlParameter("@payment", obj.Amount_Paid));
                cmd.Parameters.Add(new SqlParameter("@pdate", obj.Payment_Date));

                if (cmd.ExecuteNonQuery() > 0)
                {
                    result = true;
                }

                return result;
            }
            catch (SqlException sw)
            {
                throw sw;

            }
            finally
            {
                con.Close();
            }
        }


        public static bool Reject_Request(Reject_Request obj)
        {
            bool result = false;
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            //string q = "insert into  TEMS.Expense_Reject values (@tid,@reason,@rejectDate)";
            //SqlConnection con = new SqlConnection(cs);
            try
            {

                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "TEMS.Reject_RequestProc";
                cmd.Connection = con;
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@tid", Convert.ToInt32(obj.Expense_ReportId)));
                cmd.Parameters.Add(new SqlParameter("@reason", obj.Reason_For_Rejection));
                cmd.Parameters.Add(new SqlParameter("@rejectdate", obj.Rejection_Date));

                if (cmd.ExecuteNonQuery() > 0)
                {
                    result = true;
                }

                return result;
            }
            catch (SqlException sw)
            {
                throw sw;

            }
            finally
            {
                con.Close();
            }
        }

        public static bool ChkAmountForAccept(int id, int amount)
        {
            bool amt = true;
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string q = "select Amount_Spent from TEMS.Expense_Details where Expense_ReportId=@id ";
            //SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.ChkAmountAcceptProc";
            cmd.Connection = con;
            cmd.Parameters.Add(new SqlParameter("@id", id));
            con.Open();
            try
            {
                int a = Convert.ToInt32(cmd.ExecuteScalar());
                if (amount > a)
                {
                    amt = false;
                }
                return amt;
            }
            catch (SqlException)
            {
                return amt;
                throw;

            }
            finally
            {
                con.Close();
            }
        }

        public static bool ChangeDbAccept(int i)
        {
            bool result = false;
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);

            //string q = "update TEMS.Expense_Details set Expense_Status=@a where Expense_ReportId=@i";
            //SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.ChangeDbAcceptProc";
            cmd.Connection = con;
            cmd.Parameters.Add(new SqlParameter("@i", i));
            cmd.Parameters.Add(new SqlParameter("@a", "Approved"));
            con.Open();
            try
            {

                int r = cmd.ExecuteNonQuery();
                if (r > 0)
                    result = true;
                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.CommandText = "TEMS.ExpenseDetProc";
                //cmd.Connection = con;
                return result;
            }
            catch (SqlException)
            {
                return result;
                throw;
            }
            finally
            {
                con.Close();
            }

        }

        public static bool ChangeDbReject(int i)
        {
            bool result = false;
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= travelMngmt; Integrated Security=true";
            //string q = "update TEMS.Expense_Details set Expense_Status=@r where Expense_ReportId=@i";
            //SqlConnection con = new SqlConnection(cs);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.ChangeDbReject";
            cmd.Connection = con;

            cmd.Parameters.Add(new SqlParameter("@i", i));
            cmd.Parameters.Add(new SqlParameter("@r", "Rejected"));
            con.Open();
            try
            {

                int r = cmd.ExecuteNonQuery();
                if (r > 0)
                    result = true;
                //cmd.CommandType = CommandType.StoredProcedure;
                //cmd.CommandText = "TEMS.ExpenseDetProc";
                //cmd.Connection = con;
                return result;
            }
            catch (SqlException)
            {
                return result;
                throw;
            }
            finally
            {
                con.Close();
            }

        }

        public static bool Check_RejectDate(DateTime dt, int id)
        {
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            //string q = "select Expense_Date from TEMS.Expense_Details where Expense_ReportId=@i";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            bool checkDate = true;
            //SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            //con.Open(); 

            //string q1 = "select * from Travel_Details where Mr_No=@mr";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q1, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.Check_RejectDateProc";
            cmd.Connection = con;
            cmd.Parameters.Add(new SqlParameter("@i", id));
            con.Open();

            try
            {
                DateTime d = Convert.ToDateTime(cmd.ExecuteScalar());
                if (dt < d)
                {
                    checkDate = false;
                }

                return checkDate;
            }
            catch (TMSExceptions)
            {
                return checkDate;
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool CheckIfAlreadyAcc(int id)
        {
            bool accept = false;
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string q = "select  Expense_ReportId from TEMS.Expense_Accepted where Expense_ReportId=@i";
            //string q2 = "select  Expense_ReportId from TEMS.Expense_Reject where Expense_ReportId=@i";
            //SqlConnection con = new SqlConnection();
            SqlCommand cmd = new SqlCommand();
            SqlCommand cmd2 = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.CheckIfAlreadyAccept";
            cmd.Connection = con;

            cmd.Parameters.Add(new SqlParameter("@i", id));
            cmd2.CommandType = CommandType.StoredProcedure;
            cmd2.CommandText = "TEMS.CheckIfAlreadyReject";
            cmd2.Connection = con;
            cmd2.Parameters.Add(new SqlParameter("@i", id));
            con.Open();

            try
            {
                int r1 = Convert.ToInt32(cmd.ExecuteScalar());
                int r2 = Convert.ToInt32(cmd2.ExecuteScalar());
                if ((r1 > 0) || (r2 > 0))
                {
                    accept = true;
                }
                return accept;
            }
            catch (TMSExceptions)
            {
                return accept;
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static bool DeleteExp(int id)
        {
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string q = "Delete from TEMS.Expense_Details where Expense_ReportId=@i";
            bool checkDel = false;
            //SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            //con.Open(); 
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q1 = "select * from Travel_Details where Mr_No=@mr";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q1, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.DeleteExp";
            cmd.Connection = con;
            cmd.Parameters.Add(new SqlParameter("@i", id));
            con.Open();

            try
            {
                int r = cmd.ExecuteNonQuery();
                if (r > 0)
                    checkDel = true;

                return checkDel;
            }
            catch (TMSExceptions)
            {
                return checkDel;
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }


        public static bool CheckExists(int id)
        {
            //string cs = @"data source=ndamssql\sqlilearn ; initial catalog = Mumbai13Training ; user id = sqluser ; password = sqluser";
            //string q = "Select Expense_ReportId from TEMS.Expense_Details where Expense_ReportId=@i";
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            bool checkExists = false;
            //SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand();
            //con.Open(); 
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            //string q1 = "select * from Travel_Details where Mr_No=@mr";
            //SqlConnection con = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand(q1, con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "TEMS.CheckExistsProc";
            cmd.Connection = con;
            cmd.Parameters.Add(new SqlParameter("@i", id));
            con.Open();

            try
            {
                int r = Convert.ToInt32(cmd.ExecuteScalar());
                if (r > 0)
                    checkExists = true;

                return checkExists;
            }
            catch (TMSExceptions)
            {
                return checkExists;
                throw;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
        }

        public static int NextEmpId()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            string q = "select nextID=max(Employee_Id)+1 from TEMS.Employee";

            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            int r = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return r;
        }

        public static int NextExpRepId()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            string q = "select nextID=max(Expense_ReportId)+1 from TEMS.Expense_Details";

            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            int r = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return r;
        }

        public static int NextTravelId()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["TEMSConString"].ConnectionString);
            //string cs = @"Data Source= RAJAT-PC\RAJAT; Initial Catalog= TravelMngmt; Integrated Security=true";
            string q = "select nextID=max(MR_Number)+1 from TEMS.TravelDetails";
            //SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand(q);
            cmd.Connection = con;
            con.Open();
            int i = Convert.ToInt32(cmd.ExecuteScalar());
            con.Close();
            return i;
        }

      


    }
}