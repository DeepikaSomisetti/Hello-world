﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using BAL;
using Entities;
using System.Threading;
namespace UI
{
    /// <summary>
    /// Interaction logic for CreateExpense.xaml
    /// </summary>
    public partial class CreateExpense : Window
    {
        public CreateExpense()
        {
            InitializeComponent();
            txtEmpId.Text = Convert.ToString(UserLogin.id);
            txtEReportID.Text = Convert.ToString(BAL.BAL_Travel.NextExpRepId());
        }

        private void btnCreateExpenseReport_Click(object sender, RoutedEventArgs e)
        {
                try
                {
                    int intParsedValue;
                    DateTime parsedValue;
                    ExpenseDetails obj = new ExpenseDetails();

                    if (!int.TryParse(txtEReportID.Text, out intParsedValue))
                    {
                        MessageBox.Show("Report ID Number can't be Empty and should only contain numbers!");
                    }
                    else
                    {
                        obj.Expense_Report_Id = int.Parse(txtEReportID.Text);
                    }


                    if (!DateTime.TryParse(txtExpDate.Text, out parsedValue))
                    {
                        MessageBox.Show("Expense Date must be in correct Format (YYYY/MM/DD)");
                    }
                    else
                    {
                        obj.Expense_Date = DateTime.Parse(txtExpDate.Text);
                    }
                    obj.Account_Number = txtAccount.Text;



                    if (!int.TryParse(txtAmount.Text, out intParsedValue))
                    {
                        MessageBox.Show("Amount can't be Empty and should only contain Numbers!");
                    }
                    else
                    {
                        obj.Amount = int.Parse(txtAmount.Text);
                    }

                    obj.Payment_Type = CmbBoxPaymentType.Text;


                    if (!int.TryParse(txtMrNo.Text, out intParsedValue))
                    {
                        MessageBox.Show("MR_No can't be Empty and should only contain Numbers!");
                    }
                    else
                    {
                        obj.MR_No = int.Parse(txtMrNo.Text);
                    }
                    obj.Expense_Type = CmbBoxExpType.Text;
                    // obj.Expense_Type = CmbBoxExpType.SelectedItem.ToString();
                    
                    obj.Expense_Status = "Pending";

                    obj.ID = int.Parse(txtEmpId.Text);

                    if (BAL.BAL_Travel.Create_Expense_Details(obj))
                    {
                        MessageBox.Show("Created Succesfully!");
                    }
                    else
                    {
                        MessageBox.Show("Couldn't Create !");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
           
        

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            UserMenu um = new UserMenu();
            um.Show();
            this.Hide();
        }
    }
}
