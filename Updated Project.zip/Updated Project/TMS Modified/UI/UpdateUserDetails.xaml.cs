﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;

namespace UI
{
    /// <summary>
    /// Interaction logic for UpdateUserDetails.xaml
    /// </summary>
    public partial class UpdateUserDetails : Window
    {
        public UpdateUserDetails()
        {
            InitializeComponent();

            txtId.Text = UserLogin.id.ToString();
        }

        private void btnUpdateDetails_Click(object sender, RoutedEventArgs e)
        {
            if(BAL.BAL_Travel.Update_User_Details(txtFname.Text,txtLName.Text,txtAccNo.Text,txtPass.Text,int.Parse(txtId.Text)))
            {
                MessageBox.Show("Succesfully Update!");
                UserMenu um = new UserMenu();
                um.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Unable to Update!");
            }
        }
    }
}
