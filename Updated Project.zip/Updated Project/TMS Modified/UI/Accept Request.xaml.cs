﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using BAL;
using ExceptionTMS;

namespace UI
{
    /// <summary>
    /// Interaction logic for Accept_Request.xaml
    /// </summary>
    public partial class Accept_Request : Window
    {
        public Accept_Request()
        {
            InitializeComponent();
        }

        private void btn_Accept_Request_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                DateTime parsedValue;
                int intParsedValue;

                Request_Accept obj = new Request_Accept();
                if (!int.TryParse(txtRepId.Text, out intParsedValue))
                {
                    MessageBox.Show("Expense Report ID can't be Empty and should only contain numbers!");
                }
                else
                {
                    obj.Expense_ReportId = int.Parse(txtRepId.Text);
                }
                
                
                if (!DateTime.TryParse(txtPaymentDate.Text, out parsedValue))
                {
                    MessageBox.Show("Payment Date can't be empty and should be in correct Format (YYYY/MM/DD)");
                }
                else
                {
                    obj.Payment_Date = DateTime.Parse(txtPaymentDate.Text);
                }

                if (!int.TryParse(txtAmountPaid.Text, out intParsedValue))
                {
                    MessageBox.Show("Amount Paid can't be Empty and should only contain numbers!");
                }
                else
                {
                    obj.Amount_Paid = int.Parse(txtAmountPaid.Text);
                }
                
                
                if (BAL.BAL_Travel.Accept_Request(obj))
                {
                    MessageBox.Show("Succesfully Accepted Expense Request!");
                    if(BAL.BAL_Travel.ChangeDbAccept(obj.Expense_ReportId))
                    {
                        MessageBox.Show("Changes Succesfully made in Expense Details!");
                    }
                }
                else
                    MessageBox.Show("Error in Accepting Expense Request!");
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Back_Click(object sender, RoutedEventArgs e)
        {
            AdminMeny am = new AdminMeny();
            am.Show();
            this.Hide();
        }
    }
}
