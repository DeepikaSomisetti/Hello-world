﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Entities;
using ExceptionTMS;
using BAL;

namespace UI
{
    /// <summary>
    /// Interaction logic for RejectRequestUI.xaml
    /// </summary>
    public partial class RejectRequestUI : Window
    {
        public RejectRequestUI()
        {
            InitializeComponent();
        }


        private void btn_RejectRequest_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Reject_Request obj = new Reject_Request();
                DateTime parsedValue;
                int intParsedValue;

                if (!int.TryParse(txtRepId.Text, out intParsedValue))
                {
                    MessageBox.Show("Expense Report ID can't be Empty and should only contain numbers!");
                }
                else
                {
                    obj.Expense_ReportId = int.Parse(txtRepId.Text);
                }
                if (!DateTime.TryParse(txtRejectDate.Text, out parsedValue))
                {
                    MessageBox.Show("Rejection Date can't be empty and should be in correct Format (YYYY/MM/DD)");
                }
                else
                {
                    obj.Rejection_Date = DateTime.Parse(txtRejectDate.Text);
                }

                obj.Reason_For_Rejection = txtReason.Text;

                if (BAL.BAL_Travel.Reject_Request(obj))
                {
                    MessageBox.Show("Succesfully Rejected the request!");
                    if(BAL.BAL_Travel.ChangeDbReject(obj.Expense_ReportId))
                        {
                            MessageBox.Show("Changes Succesfully made in Expense Details!");
                        }
                }
                else
                {
                    MessageBox.Show("Error in rejecting the request!");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Back_Click_1(object sender, RoutedEventArgs e)
        {
            AdminMeny am = new AdminMeny();
            am.Show();
            this.Hide();
        }

    }
}
